﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using CMS.Models;
using Entity;
using Business;


namespace CMS.Controllers
{
    public class SubCategoryController : Controller
    {
        //
        // GET: /subcategory/

        public ActionResult Index()
        {
            subCategory subC = new subCategory();
            List<e_subCategory> lstentSubCat = new subCategoryBusiness().getAllSubcategories();
            subC.lstSubCat = ConvertToModelSubCat(lstentSubCat);
            return View(subC);
        }

        private List<subCategory> ConvertToModelSubCat(List<e_subCategory> lstentSubCat)
        {
            List<subCategory> lstSCat = new List<subCategory>();
            foreach (var item in lstentSubCat)
            {
                lstSCat.Add(new subCategory
                {
                   id=item.id,
                   categoryid=item.categoryid,
                   subcategorycode=item.subcategorycode,
                   subcategoryname=item.subcategoryname,
                   isactive = item.isactive
                });
            }
            return lstSCat;
        }
        [HttpPost]
        public ActionResult SaveSubCategory(subCategory subC)
        {
            e_subCategory e_sub = new e_subCategory();
            e_sub.categoryid=subC.categoryid;
            e_sub.subcategorycode = subC.subcategorycode;
            e_sub.subcategoryname = subC.subcategoryname;
            e_sub.isactive = subC.isactive;
            subCategoryBusiness sb = new subCategoryBusiness();
            sb.SaveSub(e_sub);

            subC = new subCategory();
            List<e_subCategory> lstentSub = new subCategoryBusiness().getAllSubcategories();
            subC.lstSubCat = ConvertToModelSubCat(lstentSub);
            return View("Index", subC);
        }

        public ActionResult DeleteSubCategory(int id)
        {
            subCategoryBusiness sb = new subCategoryBusiness();
            sb.deleteSubcategory(id);


            List<e_subCategory> lstentSubC = new subCategoryBusiness().getAllSubcategories();
            subCategory subC = new subCategory();
            subC.lstSubCat = ConvertToModelSubCat(lstentSubC);
            return View("Index", subC);
        }

        public ActionResult FindBySubCategoryId(int id)
        {
            List<e_subCategory> lstSubC = new subCategoryBusiness().getSubcategoryById(id);
            return View("Index", ConvertToModelSubCat(lstSubC)[0]);
        }

        public ActionResult ModelNull(subCategory subList)
        {
            return View("Index", new subCategory());
        }



        public ActionResult SearchSubCategoryByNameAndCode(string subcategoryname, string subcategorycode)
        {

            subCategoryBusiness sb = new subCategoryBusiness();
            List<e_subCategory> listSubs = sb.SearchSubCategoryByNameAndCode(subcategoryname, subcategorycode);
            subCategory subC = new subCategory();
            subC.lstSubCat = ConvertToModelSubCat(listSubs);
            return View("Index", subC);
        }
    }
}
