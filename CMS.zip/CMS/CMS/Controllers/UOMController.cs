﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using CMS.Models;
using Entity;
using Business;

namespace CMS.Controllers
{
    public class UOMController : Controller
    {
        //
        // GET: /UOM/

        public ActionResult Index()
        {
            UOM uoms = new UOM();
            List<e_UOM> lstentUOM = new UOMBusiness().readAllUOM();
            uoms.lstUOM = ConvertToModelUOM(lstentUOM);
            return View(uoms);
        }

        private List<UOM> ConvertToModelUOM(List<e_UOM> lstentUOM)
        {
            List<UOM> lstUOM = new List<UOM>();
            foreach (var item in lstentUOM)
            {
                lstUOM.Add(new UOM
                {
                    id = item.id,
                    UOMName=item.UOMName,
                    IsActive = item.IsActive
                });
            }
            return lstUOM;
        }
        [HttpPost]
        public ActionResult SaveUOM(UOM uom)
        {
            e_UOM uoms = new e_UOM(); 
            uoms.UOMName = uom.UOMName;
            uoms.IsActive = uom.IsActive;
            UOMBusiness ub = new UOMBusiness();
            ub.SaveUOM(uoms); 


            uom = new UOM();
            List<e_UOM> lstentUOM = new UOMBusiness().readAllUOM();
            uom.lstUOM = ConvertToModelUOM(lstentUOM);
            return View("Index", uom);
        }

        public ActionResult DeleteUOM(int id)
        {
            UOMBusiness ub = new UOMBusiness();
            ub.deleteUOM(id);


            List<e_UOM> lstentUoms = new UOMBusiness().readAllUOM();
            UOM uoms = new UOM();
            uoms.lstUOM = ConvertToModelUOM(lstentUoms);
            return View("Index", uoms);
        }

        public ActionResult FindUOMById(int id)
        {
            List<e_UOM> lstUsr = new UOMBusiness().readUOMById(id);
            return View("Index", ConvertToModelUOM(lstUsr)[0]);
        }

        public ActionResult ModelNull(UOM UomList)
        {
            return View("Index", new UOM());
        }

        public ActionResult SearchUOMByName(string Uomname)
        {

            UOMBusiness ub = new UOMBusiness();
            List<e_UOM> lstUOM = ub.SearchUOM(Uomname);
            //UOM uom = new UOM();
            //uom.lstUOM = ConvertToModelUOM(lstUOM);
            return View("Index", ConvertToModelUOM(lstUOM));
        }
    }
}
