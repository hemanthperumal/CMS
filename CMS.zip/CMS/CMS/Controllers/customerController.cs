﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using CMS.Models;
using Entity;
using Business;

namespace CMS.Controllers
{
    public class customerController : Controller
    {
        //
        // GET: /customer/

        public ActionResult Index()
        {
            customer cust = new customer();
            List<e_customer> lstentCustomers = new customerBusiness().GetAllCustomers();
            cust.lstCust = ConvertToModelCustomer(lstentCustomers);
            return View(cust);
        }

        private List<customer> ConvertToModelCustomer(List<e_customer> lstentCustomers)
        {
            List<customer> lstCusts = new List<customer>();
            foreach (var item in lstentCustomers)
            {
                lstCusts.Add(new customer
                {
                    id = item.id,
                    customername=item.customername,
                    customercode = item.customercode,
                    companyname=item.companyname,
                    address=item.address,
                    gstno=item.gstno,
                    gender = item.gender,
                    isactive=item.isactive

                });
            }
            return lstCusts;
        }
        [HttpPost]
        public ActionResult SaveCustomer(customer cust)
        {
            e_customer e_cus = new e_customer();
            e_cus.id = cust.id;
            e_cus.customername=cust.customername;
            e_cus.customercode = cust.customercode;
            e_cus.companyname = cust.companyname;
            e_cus.address = cust.address;
            e_cus.gstno = cust.gstno;
            e_cus.gender = cust.gender;
            e_cus.isactive = cust.isactive;
            customerBusiness cb = new customerBusiness();
            cb.SaveCustomer(e_cus);

            cust = new customer();
            List<e_customer> lstentCusts = new customerBusiness().GetAllCustomers();
            cust.lstCust = ConvertToModelCustomer(lstentCusts);
            return View("Index", cust);
        }

        public ActionResult DeleteCustomer(int id)
        {
            customerBusiness cb = new customerBusiness();
            cb.DeleteCustomer(id);


            List<e_customer> lstentCusts = new customerBusiness().GetAllCustomers();
            customer cust = new customer();
            cust.lstCust = ConvertToModelCustomer(lstentCusts);
            return View("Index", cust);
        }

        public ActionResult FindCustomerById(int id)
        {
            List<e_customer> lstCust = new customerBusiness().GetCustomerById(id);
            return View("Index", ConvertToModelCustomer(lstCust)[0]);
        }

        public ActionResult ModelNull(customer custlst)
        {
            return View("Index", new customer());
        }



        public ActionResult SearchByCustomerNameAndCompanyName(string customername, string companyname)
        {

            customerBusiness cb = new customerBusiness();
            List<e_customer> listCusts = cb.SearchCustomer(customername, companyname);
            customer cust = new customer();
            cust.lstCust = ConvertToModelCustomer(listCusts);
            return View("Index", cust);
        }

    }
}
