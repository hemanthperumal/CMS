﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Entity;
using Business;
using CMS.Models;

namespace CMS.Controllers
{
    public class itemController : Controller
    {
        //
        // GET: /item/

        public ActionResult Index()
        {
            item itm = new item();
            List<e_item> lstentItems = new itemBusiness().GetAllItems();
            itm.lstItem = ConvertToModelItem(lstentItems);
            return View(itm);
        }

        private List<item> ConvertToModelItem(List<e_item> lstentItems)
        {
            List<item> lstItem = new List<item>();
            foreach (var item in lstentItems)
            {
                lstItem.Add(new item
                {
                    id = item.id,
                    categoryid=item.categoryid,
                    subcategoryid = item.subcategoryid,
                    productname = item.productname,
                    productcode=item.productcode,
                    isactive=item.isactive
                    
                });
            }
            return lstItem;
        }
        [HttpPost]
        public ActionResult SaveItem(item itm)
        {
            e_item eitm = new e_item();
            eitm.id = itm.id;
            eitm.categoryid = itm.categoryid;
            eitm.subcategoryid = itm.subcategoryid;
            eitm.productname = itm.productname;
            eitm.productcode = itm.productcode;
            eitm.isactive = itm.isactive;
            itemBusiness ib = new itemBusiness();
            ib.SaveItem(eitm);

            itm = new item();
            List<e_item> lstentItem = new itemBusiness().GetAllItems();
            itm.lstItem = ConvertToModelItem(lstentItem);
            return View("Index", itm);
        }

        public ActionResult DeleteItem(int id)
        {
            itemBusiness ib = new itemBusiness();
            ib.DeleteItem(id);


            List<e_item> lstentItems = new itemBusiness().GetAllItems();
            item itm = new item();
            itm.lstItem = ConvertToModelItem(lstentItems);
            return View("Index", itm);
        }

        public ActionResult FindItemById(int id)
        {
            List<e_item> lstItem = new itemBusiness().GetItemById(id);
            return View("Index", ConvertToModelItem(lstItem)[0]);
        }

        public ActionResult ModelNull(item itemlst)
        {
            return View("Index", new item());
        }



        public ActionResult SearchItemByproductnameAndCode(string productname, string productcode)
        {

            itemBusiness ib = new itemBusiness();
            List<e_item> listItem = ib.SearchItem(productname, productcode);
            item itm = new item();
            itm.lstItem = ConvertToModelItem(listItem);
            return View("Index", itm);
        }

    }
}
