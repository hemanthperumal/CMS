﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace CMS.Models
{
    public class payment
    {
        public int id { get; set; }
        [Required]
        [Display(Name = "Billing ID")]
        public int billingid { get; set; }
        [Required]
        [Display(Name = "Paid Amount")]
        public float paidamount { get; set; }
        [Required]
        [Display(Name = "Paid Date")]
        public DateTime paiddate { get; set; }
        [Required]
        [Display(Name = "Payment Ref.No")]
        public int paymentrefno { get; set; }
        [Required]
        [Display(Name = "IS Active")]
        public bool isactive { get; set; }
        public List<payment> lstPay { get; set; }

    }
}
