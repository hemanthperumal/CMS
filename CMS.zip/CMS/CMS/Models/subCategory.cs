﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace CMS.Models
{
    public class subCategory
    {
        public int id { get; set; }
        [Required]
        [Display(Name = "Category ID")]
        public int categoryid { get; set; }
        [Required]
        [Display(Name = "Sub Category Code")]
        public string subcategorycode { get; set; }
        [Required]
        [Display(Name = "Sub Category Name")]
        public string subcategoryname { get; set; }
        [Required]
        [Display(Name = "IS Active")]
        public bool isactive { get; set; }

        public List<subCategory> lstSubCat { get; set; }

    }
}
