﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Common;
using DataAccess;
using Entity;

namespace Business
{
    public class BillingItemBusiness
    {

        BillingItemDB db = new BillingItemDB();


        public List<e_billingitem> getAllBillingItems()
        {
            return db.GetAllBillingitems();
        }


        public List<e_billingitem> getBillingItemById(int id)
        {
            return db.GetBillingitemByID(id);
        }

        public List<e_billingitem> SearchBillItem(int itemid,int qty)
        {
            return db.SearchBillItem(itemid,qty);
        }


        public void updateBillingItem(e_billingitem b_item)
        {
            db.UpdateBillingItem(b_item);
        }


        public void deleteBillingItem(int id)
        {
            db.DeleteBillingItem(id);
        }


        public void SaveBillingItem(e_billingitem billItem)
        {
            if (billItem.id > 0)
            {
                db.UpdateBillingItem(billItem);
            }
            else
            {
                db.InsertBillingItem(billItem);
            }
        }
    }

}
