﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Common
{
    public class Constants
    {
        //Stored Procedures for Billing in CMS
        public const string STORED_PROCEDURE_DELETE_BILLING = "deleteBilling";
        public const string SP_UpdateBilling = "UPDATEbilling";
        public const string SP_InsertBilling = "INSERTbilling";
        public const string SP_GetBillingById = "getBillingById";
        public const string SP_GetAllBillings = "getAllBillings";
        public const string SP_SearchByBillNoAndInvoiceDate = "SearchByBillNoAndInvoiceDate";

        //Category
        public const string SP_DeleteCategory = "deleteCategory";
        public const string SP_ReadAllCategories = "readAllCategory";
        public const string SP_GetCategoryById = "getCategoryById";
        public const string SP_InsertCategory = "InsertCategory";
        public const string SP_UpdateCategory = "UpdateCategory";
        public const string SP_SearchByCategoryNameAndCode = "SearchByCategoryNameAndCode";

        //user
        public const string SP_DeleteUser = "deleteUser";
        public const string SP_GetAllUsers = "readAllUsers";
        public const string SP_GetUserById = "readUserById";
        public const string SP_InsertUser = "INSERTUser";
        public const string SP_UpdateUser = "updateUser";
        public const string SP_SearchUserByNameAndRole = "SelectByUserNameANDUserRole";

        //UOM
        public const string SP_UpdateUOM = "updateUOM";
        public const string SP_DeleteUOM = "deleteUOM";
        public const string SP_InsertUOM = "InsertUOM";
        public const string SP_GetAllUOM = "getAllUOM";
        public const string SP_GetUOMById = "getUOMById";
        public const string SP_SearchUOMByUOMName = "SelectByUOMName";

        //subcategory
        public const string SP_UpdateSubCategory = "Updatesubcategory";
        public const string SP_InsertSubCategory = "Insertsubcategory";
        public const string SP_GetSubCategoryById = "getSubcategoryById";
        public const string SP_GetAllSubCategories = "getAllSubcategories";
        public const string SP_DeleteSubCategory = "deletesubcategory";
        public const string SP_SearchBySubCategoryNameAndSubCatCode = "SearchBySubCategoryNameAndSubCatCode";

        //payment
        public const string SP_DeletePayment = "deletePayment";
        public const string SP_GetAllPayments = "getAllPayments";
        public const string SP_GetPaymentById = "getPaymentById";
        public const string SP_InsertPayment = "InsertPayment";
        public const string SP_UpdatePayment = "UpdatePayment";
        public const string SP_SearchByPaymentRef = "SearchByPaymentRef";

        //company
        public const string SP_GetAllCompanies = "ReadAllCompany";
        public const string SP_GetCompanyById = "getCompanyById";
        public const string SP_deleteCompany = "deleteCompany";
        public const string SP_InsertCompany = "InsertCompany";
        public const string SP_UpdateCompany = "updateCompany";
        public const string SP_SearchCompanyByCompanyNameAndEmail = "SearchCompanyByCompanyNameAndEmail";

        //billingitem
        public const string SP_DeleteBillingItem = "deleteBillingItem";
        public const string SP_GetAllBillingItems = "getAllBillingItems";
        public const string SP_GetBillingItemById = "getBillingItemById";
        public const string SP_InsertBillingItem = "insertBillingItem";
        public const string SP_UpdateBillingItem = "UpdateBillingItem";
        public const string SP_SearchBillItemByitemAndQty = "SearchBillItemByitemAndQty";


        //customermaster
        public const string SP_DeleteCustomer = "deletecust";
        public const string SP_UpdateCustomer = "updatecustomer";
        public const string SP_InsertCustomer = "insertcustomer";
        public const string SP_GetAllCustomers = "getallcustomers";
        public const string SP_GetCustomerById = "getcustomerbyid";
        public const string SP_SearchByCustomerNameAndCompanyName = "SearchByCustomerNameAndCompanyName";

        //items
        public const string SP_DeleteItem = "deleteItem";
        public const string SP_UpdateItem = "updateItem";
        public const string SP_InsertItem = "InsertItem";
        public const string SP_GetAllItems = "getAllItem";
        public const string SP_GetItemById = "fetchItem";
        public const string SP_SearchItemByproductnameAndCode = "SearchItemByproductnameAndCode";

    }
}
