﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data.Sql;
using System.Configuration;
using System.Data;
using Common;
using Entity;

namespace DataAccess
{
    public class UOMDB
    {
        long result = 0;
        SqlConnection sqlCon = new SqlConnection(ConfigurationManager.ConnectionStrings["CONSTR"].ConnectionString);


        public long DeleteUOM(int id)
        {
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = sqlCon;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = Constants.SP_DeleteUOM;
                    cmd.Parameters.AddWithValue("@id", id);
                    sqlCon.Open();
                    result = cmd.ExecuteNonQuery();
                }
            }
            catch (Exception e)
            {
                throw e;
            }
            finally
            {
                sqlCon.Close();
            }
            return result;
        }


        public List<e_UOM> GetAllUOM()
        {
            List<e_UOM> lstUOM = new List<e_UOM>();

            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = sqlCon;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = Constants.SP_GetAllUOM;
                    //cmd.Parameters.AddWithValue("@id", id);
                    sqlCon.Open();
                    // result = cmd.ExecuteNonQuery();
                    SqlDataReader reader = cmd.ExecuteReader();
                    while (reader.Read())
                    {
                        e_UOM uom = new e_UOM();
                        uom.id = Convert.ToInt32(reader.GetValue(0).ToString());
                        uom.UOMName = reader.GetValue(1).ToString();
                        uom.IsActive =Convert.ToBoolean( reader.GetValue(2).ToString() == "1" ? true:false);
                        lstUOM.Add(uom);
                    }
                    reader.Close();

                }
            }
            catch (Exception e)
            {
                throw e;
            }
            finally
            {
                sqlCon.Close();
            }
            return lstUOM;
        }


        public List<e_UOM> GetUOMByID(int id)
        {
            List<e_UOM> lstUOM = new List<e_UOM>();

            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = sqlCon;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = Constants.SP_GetUOMById;
                    cmd.Parameters.AddWithValue("@id", id);
                    sqlCon.Open();
                    // result = cmd.ExecuteNonQuery();
                    SqlDataReader reader = cmd.ExecuteReader();
                    while (reader.Read())
                    {
                        e_UOM uom = new e_UOM();
                        uom.id = Convert.ToInt32(reader.GetValue(0).ToString());
                        uom.UOMName = reader.GetValue(1).ToString();
                        uom.IsActive = Convert.ToBoolean(reader.GetValue(2).ToString() == "1" ? true : false);
                        lstUOM.Add(uom);
                    }
                    reader.Close();

                }
            }
            catch (Exception e)
            {
                throw e;
            }
            finally
            {
                sqlCon.Close();
            }
            return lstUOM;
        }

        public long InsertUOM(e_UOM uom)
        {
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = sqlCon;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = Constants.SP_InsertUOM;
                    //cmd.Parameters.AddWithValue("@id", uom.id);
                    cmd.Parameters.AddWithValue("@UOMName", uom.UOMName);
                    cmd.Parameters.AddWithValue("@IsActive", uom.IsActive);
                    sqlCon.Open();
                    result = cmd.ExecuteNonQuery();
                }
            }
            catch (Exception e)
            {
                throw e;
            }
            finally
            {
                sqlCon.Close();
            }
            return result;

        }


        public long UpdateUOM(e_UOM uom)
        {
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = sqlCon;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = Constants.SP_UpdateUOM;
                    cmd.Parameters.AddWithValue("@id", uom.id);
                    cmd.Parameters.AddWithValue("@UOMName", uom.UOMName);
                    cmd.Parameters.AddWithValue("@IsActive", uom.IsActive);
                    sqlCon.Open();
                    result = cmd.ExecuteNonQuery();
                }
            }
            catch (Exception e)
            {
                throw e;
            }
            finally
            {
                sqlCon.Close();
            }
            return result;

        }

        public List<e_UOM> SearchUOM(string UomName)
        {
            List<e_UOM> lstUOM = new List<e_UOM>();

            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = sqlCon;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = Constants.SP_SearchUOMByUOMName;
                    cmd.Parameters.AddWithValue("@UomName", UomName);
                    sqlCon.Open();
                    // result = cmd.ExecuteNonQuery();
                    SqlDataReader reader = cmd.ExecuteReader();
                    while (reader.Read())
                    {
                        e_UOM uom = new e_UOM();
                        uom.id = Convert.ToInt32(reader.GetValue(0).ToString());
                        uom.UOMName = reader.GetValue(1).ToString();
                        uom.IsActive = Convert.ToBoolean(reader.GetValue(2).ToString() == "1" ? true : false);
                        lstUOM.Add(uom);
                    }
                    reader.Close();

                }
            }
            catch (Exception e)
            {
                throw e;
            }
            finally
            {
                sqlCon.Close();
            }
            return lstUOM;
        }
    }

}
