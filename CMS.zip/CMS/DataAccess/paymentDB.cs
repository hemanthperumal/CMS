﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data.Sql;
using System.Configuration;
using System.Data;
using Common;
using Entity;


namespace DataAccess
{
    public class paymentDB
    {
        long result = 0;
        SqlConnection sqlCon = new SqlConnection(ConfigurationManager.ConnectionStrings["CONSTR"].ConnectionString);


        public long DeletePayment(int id)
        {
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = sqlCon;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = Constants.SP_DeletePayment;
                    cmd.Parameters.AddWithValue("@id", id);
                    sqlCon.Open();
                    result = cmd.ExecuteNonQuery();
                }
            }
            catch (Exception e)
            {
                throw e;
            }
            finally
            {
                sqlCon.Close();
            }
            return result;
        }


        public List<e_payment> GetAllPayments()
        {
            List<e_payment> lstpay = new List<e_payment>();

            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = sqlCon;
                    sqlCon.Open();
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = Constants.SP_GetAllPayments;
                    SqlDataReader reader = cmd.ExecuteReader();
                    while (reader.Read())
                    {
                        e_payment epay = new e_payment();
                        epay.id = Convert.ToInt32(reader.GetValue(0).ToString());
                        epay.billingid = Convert.ToInt32(reader.GetValue(1).ToString());
                        epay.paidamount = float.Parse(reader.GetValue(2).ToString());
                        epay.paiddate = Convert.ToDateTime( reader.GetValue(3).ToString());
                        epay.paymentrefno = Convert.ToInt32(reader.GetValue(4).ToString());
                        epay.isactive = Convert.ToBoolean(reader.GetValue(5).ToString() == "1" ? true : false);
                        lstpay.Add(epay);
                    }
                    reader.Close();

                }
            }
            catch (Exception e)
            {
                throw e;
            }
            finally
            {
                sqlCon.Close();
            }
            return lstpay;
        }


        public List<e_payment> GetPaymentByID(int id)
        {
            List<e_payment> lstpay = new List<e_payment>();

            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = sqlCon;
                    sqlCon.Open();
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = Constants.SP_GetPaymentById;
                    cmd.Parameters.AddWithValue("@id",id);
                    SqlDataReader reader = cmd.ExecuteReader();
                    while (reader.Read())
                    {
                        e_payment epay = new e_payment();
                        epay.id = Convert.ToInt32(reader.GetValue(0).ToString());
                        epay.billingid = Convert.ToInt32(reader.GetValue(1).ToString());
                        epay.paidamount = float.Parse(reader.GetValue(2).ToString());
                        epay.paiddate = Convert.ToDateTime(reader.GetValue(3).ToString());
                        epay.paymentrefno = Convert.ToInt32(reader.GetValue(4).ToString());
                        epay.isactive = Convert.ToBoolean(reader.GetValue(5).ToString() == "1" ? true : false);
                        lstpay.Add(epay);
                    }
                    reader.Close();

                }
            }
            catch (Exception e)
            {
                throw e;
            }
            finally
            {
                sqlCon.Close();
            }
            return lstpay;
        }

        public long InsertPayment(e_payment pay)
        {
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = sqlCon;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = Constants.SP_InsertPayment;
                   // cmd.Parameters.AddWithValue("@ID", pay.id);
                    cmd.Parameters.AddWithValue("@billingid", pay.billingid);
                    cmd.Parameters.AddWithValue("@paidamount", pay.paidamount);
                    cmd.Parameters.AddWithValue("@paiddate", pay.paiddate);
                    cmd.Parameters.AddWithValue("@paymentrefno", pay.paymentrefno);
                    cmd.Parameters.AddWithValue("@isactive", pay.isactive);
                    sqlCon.Open();
                    result = cmd.ExecuteNonQuery();
                }
            }
            catch (Exception e)
            {
                throw e;
            }
            finally
            {
                sqlCon.Close();
            }
            return result;
        }


        public long UpdatePayment(e_payment pay)
        {
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = sqlCon;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = Constants.SP_UpdatePayment;
                    cmd.Parameters.AddWithValue("@ID", pay.id);
                    cmd.Parameters.AddWithValue("@billingid", pay.billingid);
                    //cmd.Parameters.AddWithValue("@paidamount", pay.paidamount);
                    cmd.Parameters.AddWithValue("@paiddate", pay.paiddate);
                    cmd.Parameters.AddWithValue("@paymentrefno", pay.paymentrefno);
                    cmd.Parameters.AddWithValue("@isactive", pay.isactive);
                    sqlCon.Open();
                    result = cmd.ExecuteNonQuery();
                }
            }
            catch (Exception e)
            {
                throw e;
            }
            finally
            {
                sqlCon.Close();
            }
            return result;
        }

        public List<e_payment> SearchPaymentByPayRefNo(int paymentrefno)
        {
            List<e_payment> lstpay = new List<e_payment>();

            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = sqlCon;
                    sqlCon.Open();
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = Constants.SP_SearchByPaymentRef;
                    cmd.Parameters.AddWithValue("@paymentrefno", paymentrefno);
                    SqlDataReader reader = cmd.ExecuteReader();
                    while (reader.Read())
                    {
                        e_payment epay = new e_payment();
                        epay.id = Convert.ToInt32(reader.GetValue(0).ToString());
                        epay.billingid = Convert.ToInt32(reader.GetValue(1).ToString());
                        epay.paidamount = float.Parse(reader.GetValue(2).ToString());
                        epay.paiddate = Convert.ToDateTime(reader.GetValue(3).ToString());
                        epay.paymentrefno = Convert.ToInt32(reader.GetValue(4).ToString());
                        epay.isactive = Convert.ToBoolean(reader.GetValue(5).ToString() == "1" ? true : false);
                        lstpay.Add(epay);
                    }
                    reader.Close();

                }
            }
            catch (Exception e)
            {
                throw e;
            }
            finally
            {
                sqlCon.Close();
            }
            return lstpay;
        }
    }

}
