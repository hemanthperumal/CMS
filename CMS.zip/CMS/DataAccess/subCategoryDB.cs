﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data.Sql;
using System.Configuration;
using System.Data;
using Common;
using Entity;


namespace DataAccess
{
    public class SubCategoryDB
    {
        long result = 0;
        SqlConnection sqlCon = new SqlConnection(ConfigurationManager.ConnectionStrings["CONSTR"].ConnectionString);


        public long DeleteSubCategory(int id)
        {
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = sqlCon;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = Constants.SP_DeleteSubCategory;
                    cmd.Parameters.AddWithValue("@ID", id);
                    sqlCon.Open();
                    result = cmd.ExecuteNonQuery();
                }
            }
            catch (Exception e)
            {
                throw e;
            }
            finally
            {
                sqlCon.Close();
            }
            return result;
        }


        public List<e_subCategory> GetAllSubCategories()
        {
            List<e_subCategory> lstSub = new List<e_subCategory>();

            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = sqlCon;
                    sqlCon.Open();
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = Constants.SP_GetAllSubCategories;
                    SqlDataReader reader = cmd.ExecuteReader();
                    while (reader.Read())
                    {
                        e_subCategory sub = new e_subCategory();
                        sub.id = Convert.ToInt32(reader.GetValue(0).ToString());
                        sub.categoryid = Convert.ToInt32(reader.GetValue(1).ToString());
                        sub.subcategorycode = reader.GetValue(2).ToString();
                        sub.subcategoryname = reader.GetValue(3).ToString();
                        sub.isactive = Convert.ToBoolean(reader.GetValue(4).ToString() == "1" ? true : false);
                        lstSub.Add(sub);
                    }
                    reader.Close();

                }
            }
            catch (Exception e)
            {
                throw e;
            }
            finally
            {
                sqlCon.Close();
            }
            return lstSub;
        }


        public List<e_subCategory> GetSubCategorybyID(int id)
        {
            List<e_subCategory> lstSub = new List<e_subCategory>();

            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = sqlCon;
                    sqlCon.Open();
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = Constants.SP_GetSubCategoryById;
                    cmd.Parameters.AddWithValue("@id",id);
                    SqlDataReader reader = cmd.ExecuteReader();
                    while (reader.Read())
                    {
                        e_subCategory sub = new e_subCategory();
                        sub.id = Convert.ToInt32(reader.GetValue(0).ToString());
                        sub.categoryid = Convert.ToInt32(reader.GetValue(1).ToString());
                        sub.subcategorycode = reader.GetValue(2).ToString();
                        sub.subcategoryname = reader.GetValue(3).ToString();
                        sub.isactive = Convert.ToBoolean(reader.GetValue(4).ToString() == "1" ? true : false);
                        lstSub.Add(sub);
                    }
                    reader.Close();

                }
            }
            catch (Exception e)
            {
                throw e;
            }
            finally
            {
                sqlCon.Close();
            }
            return lstSub;
        }


        public long InsertSubCategory(e_subCategory subcat)
        {
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = sqlCon;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = Constants.SP_InsertSubCategory;
                    cmd.Parameters.AddWithValue("@categoryid", subcat.categoryid);
                    cmd.Parameters.AddWithValue("@subcategoryname", subcat.subcategoryname);
                    cmd.Parameters.AddWithValue("@subcategorycode", subcat.subcategorycode);
                    cmd.Parameters.AddWithValue("@IsActive", subcat.isactive);
                    sqlCon.Open();
                    result = cmd.ExecuteNonQuery();
                }
            }
            catch (Exception e)
            {
                throw e;
            }
            finally
            {
                sqlCon.Close();
            }
            return result;
        }


        public long UpdateSubCategory(e_subCategory subcat)
        {
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = sqlCon;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = Constants.SP_UpdateSubCategory;
                    cmd.Parameters.AddWithValue("@ID", subcat.id);
                    cmd.Parameters.AddWithValue("@categoryid", subcat.categoryid);
                    cmd.Parameters.AddWithValue("@subcategoryname", subcat.subcategoryname);
                    cmd.Parameters.AddWithValue("@subcategorycode", subcat.subcategorycode);
                    cmd.Parameters.AddWithValue("@IsActive", subcat.isactive);
                    sqlCon.Open();
                    cmd.ExecuteNonQuery();
                }
            }
            catch (Exception e)
            {
                throw e;
            }
            finally
            {
                sqlCon.Close();
            }
            return result;
        }

        public List<e_subCategory> SearchSubCategory(string subcategoryname,string subcategorycode)
        {
            List<e_subCategory> lstSub = new List<e_subCategory>();

            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = sqlCon;
                    sqlCon.Open();
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = Constants.SP_SearchBySubCategoryNameAndSubCatCode;
                    cmd.Parameters.AddWithValue("@subcategoryname", subcategoryname);
                    cmd.Parameters.AddWithValue("@subcategorycode", subcategorycode);
                    SqlDataReader reader = cmd.ExecuteReader();
                    while (reader.Read())
                    {
                        e_subCategory sub = new e_subCategory();
                        sub.id = Convert.ToInt32(reader.GetValue(0).ToString());
                        sub.categoryid = Convert.ToInt32(reader.GetValue(1).ToString());
                        sub.subcategorycode = reader.GetValue(2).ToString();
                        sub.subcategoryname = reader.GetValue(3).ToString();
                        sub.isactive = Convert.ToBoolean(reader.GetValue(4).ToString() == "1" ? true : false);
                        lstSub.Add(sub);
                    }
                    reader.Close();

                }
            }
            catch (Exception e)
            {
                throw e;
            }
            finally
            {
                sqlCon.Close();
            }
            return lstSub;
        }
    }
}
